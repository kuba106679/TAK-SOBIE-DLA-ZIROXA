# esx_vangelico_robbery
ESX Vangelico Robbery V 2.0.0

[REQUIREMENTS]

  * FiveM-ipl   => https://github.com/ESX-PUBLIC/fivem-ipl
  * esx_policejob => https://github.com/ESX-Org/esx_policejob
  * esx_ambulancejob => https://github.com/ESX-Org/esx_ambulancejob

[INSTALLATION]

1) CD in your resources/[esx] folder
2) Clone the repository
3) Import esx_vangelico_robbery.sql in your database
4) Add this in your server.cfg :

```
start esx_vangelico_robbery
```

[ORIGINAL SCRIPT]

  * esx_holdup => https://github.com/ESX-Org/esx_holdup

[OLD VIDEO]

  * https://www.youtube.com/watch?v=MivP5hU5m8A

[NEW VIDEO]

  * https://streamable.com/y11r7