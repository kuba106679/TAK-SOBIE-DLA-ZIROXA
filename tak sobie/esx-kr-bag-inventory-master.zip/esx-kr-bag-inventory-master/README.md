
> **ESX-KR-BAG-INVENTORY**

**Features**

_- Synced with all players_

_- You have the ability to put weapons and items in your bag_

_- If you drop your bag with the items inside all items will drop with the bag_

_- All bags and it's items are saved in a database_

_- All dropped bags respawn after restarting the server_

**Usage**

_- The script was made to promote roleplaying_

_- The default key to open the bag is F5_


**Installation**

1. Download the files and insert them into your resource folder.
2. Start the esx-kr-bag-inventory in your server.cfg
3. Insert the sql to your database.
4. If you want the bag in your shop you'll have to insert this row

```INSERT INTO `shops` (store, item, price) VALUES
	('TwentyFourSeven','bag',1000),
	('RobsLiquor','bag',1000),
	('LTDgasoline','bag',1000);```

**Video**

https://streamable.com/a4y2o
