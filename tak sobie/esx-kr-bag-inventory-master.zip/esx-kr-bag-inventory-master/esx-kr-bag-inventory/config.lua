Config                            = {}

Config.MaxItemCount = 50 
Config.MaxDifferentItems = 5
