server_script "server.lua"
client_script "truckerjob.lua"