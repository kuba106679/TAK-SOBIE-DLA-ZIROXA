Locales['de'] = {
    ['invalid_amount'] = '~r~Ungültige Summe!',
    ['broke_amount'] = "~r~Du hast nicht genug Bank-Guthaben zur verfügung!",
    ['sold'] = "~g~Aktien-Anteile erfolgreich verkauft!",
    ['buy'] = "~g~Aktien-Anteile erfolgreich gekauft",
    ['added'] = "Du hast mehr Geld in deine Aktien investiert!",
    ['unexpected_error'] = "~r~Ein plötzlicher Fehler ist aufgetreten.",
    ['open_menu'] = "Drücke ~INPUT_PICKUP~ um deine Aktien zu verwalten"
}