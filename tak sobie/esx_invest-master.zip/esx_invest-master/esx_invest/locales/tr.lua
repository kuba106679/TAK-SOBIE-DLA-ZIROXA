Locales['tr'] = {
    ['invalid_amount'] = '~r~Geçersiz değer',
    ['broke_amount'] = "~r~Yeterli miktarda paran yok",
    ['sold'] = "~g~Hisse senetiniz satıldı",
    ['buy'] = "~g~Hisse senetini satın aldınız.",
    ['added'] = "Senetinize daha fazla yatırım yaptınız",
    ['unexpected_error'] = "~r~Beklenmeyen bir hata oluştu",
    ['open_menu'] = "~INPUT_PICKUP~ Menüyü Aç",
    ['to_much'] = "~r~Girdiğiniz tutar çok fazla. En yükdek {limit} tutarını girebilirsiniz."
}
