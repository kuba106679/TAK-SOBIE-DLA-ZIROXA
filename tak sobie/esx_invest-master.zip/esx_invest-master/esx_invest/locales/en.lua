Locales['en'] = {
    ['invalid_amount'] = '~r~Invalid amount',
    ['broke_amount'] = "~r~You don't have that amount on your bank",
    ['sold'] = "~g~Your stock share has been sold",
    ['buy'] = "~g~You successfully bought a share",
    ['added'] = "You've successfully invested more in your share",
    ['unexpected_error'] = "~r~An unexpected error has occurred",
    ['open_menu'] = "Press ~INPUT_PICKUP~ to open",
    ['to_much'] = "~r~Your amount is to much, the limit is {limit}"
}