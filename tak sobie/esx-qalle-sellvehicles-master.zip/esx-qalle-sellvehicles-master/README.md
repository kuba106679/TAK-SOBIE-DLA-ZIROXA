# esx-qalle-sellvehicles

[NOTES]

* This gives you the opportunity to sell your vehicle to another player with modifications and own price.

* If you find any bug, lemme know and i'll fix it as quick as possible.

* If you got feedback how to do it better, lemme know and i'll redo it.

* Right now you can only sell 11 vehicles max, you can add more by adding more positions in Config.SellPositions

* This is like an dealership for used cars.

[REQUIREMENTS]
  
* ESX
* esx_vehicleshop

[INSTALLATION]

1) Download: https://github.com/qalle-fivem/esx-qalle-sellvehicles

2) Import SQL

3) Add this in your server.cfg :
``start esx-qalle-sellvehicles``

[SCREENSHOTS]

