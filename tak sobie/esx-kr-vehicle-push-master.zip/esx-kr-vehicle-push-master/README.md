> ESX-KR-VEHCICLE-PUSH

**Features**
 _- You can push broken vehicles of the street_

**Installation**

1. Download the files and insert them into your resouce folder.
2. Write esx-kr-vehicle-push in your server.cfg.

**Note**
I made parts of this script with Zeb.

Some of you may not be attached to the vehicle due to missing streaming.lua in es_extended, either update es_extended or add streaming.lua by downloading new es_extended and copying streaming.lua into your client folded and add it to your resource.lua /Zeb

Video
**https://streamable.com/pv8ed**


