CREATE TABLE `jsfour_atm` (
  `identifier` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `account` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL
);
