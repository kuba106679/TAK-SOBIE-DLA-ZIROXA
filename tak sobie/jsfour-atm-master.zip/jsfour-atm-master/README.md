I have translated this script with help from Jonas into English. It's a basic drag, drop and start. This script replaces 'new_banking'

It adds a usable ATM to your game.
press the card slot to insert your card then press the keypad to enter your pin code (it's any code).
It takes about 5 seconds to complete 2000. 
If you have to withdraw or deposit a larger amount of money then you can visit a bank and do so inside.

### INSTALLATION
* Drag the script in your resource folder
* Add to your server.cfg
* Insert the sql file into your database
* Profit!

### SCREENSHOTS
[Screenshot] (https://imgur.com/13fUIkM)

Video: https://streamable.com/b1p2d


Swedish
# jsfour-atm
En realistisk bankomat

### LICENSE
Du får mer än gärna ändra vad du vill i scriptet men du får INTE sälja vidare scriptet eller ladda upp det på nytt, hänvisa folket hit istället.

### INFO
Det tar ca 5 sekunder att ta ut 2000. Ska man då ta ut större belopp så får man besöka en bank och via disk ta ut valfri summa.
Koden för att använda bankomaten är 1111 för alla spelare.

### INSTALLATION
* Lägg in scriptet i din resource-mapp
* Lägg in sql-filen i din databas

### SCREENSHOTS
![screenshot](https://i.gyazo.com/c97621f5ea7291c97eeca77197b83e6c.png)
![screenshot](https://i.gyazo.com/3da3bf7dff1af26317aa95d863ccaeea.png)


Video: https://streamable.com/b1p2d
