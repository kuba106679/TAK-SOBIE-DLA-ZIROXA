Locales['es'] = {
	['shop'] = 'tienda',
	['shops'] = 'tiendas',
	['press_menu'] = 'presiona ~INPUT_CONTEXT~ para acceder a la tienda.',
	['bought'] = 'you just bought ~y~%sx~s~ ~b~%s~s~ for ~r~$%s~s~',
	['not_enough'] = 'no tienes ~r~suficiente ~s~ dinero: %s',
	['player_cannot_hold'] = 'you do ~r~not~s~ have enough ~y~free space~s~ in your inventory!',
	['shop_confirm'] = 'buy %sx %s for $%s?',
	['no'] = 'no',
	['yes'] = 'yes',
}
