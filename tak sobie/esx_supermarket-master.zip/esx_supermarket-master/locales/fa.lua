Locales['fa'] = {
	['shop'] = 'maghaze',
	['shops'] = 'maghaze ha',
	['press_menu'] = 'baraye dastresi be ~y~store~s~ lotfan ~INPUT_CONTEXT~ ro bezanid.',
	['bought'] = '~y~%sx~s~ ~b~%s~s~ ra be gheymate ~r~$%s~s~ kharidid.',
	['not_enough'] = 'shome meghdare ~r~kafi~s~ pool nadarid, ~r~$%s~s~ pool kam darid!',
	['player_cannot_hold'] = '~r~jaye kafi nadarid~s~!',
	['shop_confirm'] = 'resid: %sx %s be ezaye $%s?',
	['no'] = 'na',
	['yes'] = 'kharid',
}